import json
import os
import argparse
import requests
import validators
from reachability import Reachability
from requests.exceptions import MissingSchema


# By Ivanov Pavel (Skillfactory 2023 MIFI3)
# Объявляем функцию пинга.
def do_ping_sweep(ip, num_of_host):
    if not validators.ipv4(ip):
        print(f"[#] Target host or gateway '{ip}' is not valid, enter valid IP and try again. Bye")
        return
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)

    response = os.popen(f'ping -c 2 {scanned_ip}')
    res = response.readlines()
    print(f"[#] Result of scanning: {scanned_ip} [#]\n{res[-2]}", end='\n')


# Объявляем функцию http запросов.
def sent_http_request(target, method, headers=None, payload=None):
    headers_dict = {}
    try:
        # Работаем с заголовками (добавляем в словарь)
        if headers:
            for header in headers:
                header_name = header.split(':')[0]
                header_value = header.split(':')[1:]
                headers_dict[header_name] = ':'.join(header_value)
        if method == "GET":
            response = requests.get(target, headers=headers_dict)
        elif method == "POST":
            response = requests.post(target, headers=headers_dict, data=payload)
        else:
            print(f"[#] Method {method} is not supported. Run again with methods GET or POST. Bye")
            return
        print(
            f"[#] Response status code: {response.status_code}\n"
            f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
            f"[#] Response content:\n {response.text}"
        )
    # Обрабатываем ошибки:
    except requests.exceptions.ConnectionError:
        print('[#] Connection error, maybe there is typo in URL or it does not exist or failed to resolve. Sorry, bye.')
    except MissingSchema:
        print('[#] The Schema "https://" is missing. Try again.')


# Работаем с аргументами (парсим)
parser = argparse.ArgumentParser(description='Network scanner')
parser.add_argument('task', choices=['scan', 'sendhttp'], help='Network scan or send HTTP request')
parser.add_argument('-i', '--ip', type=str, help='IP address')
parser.add_argument('-n', '--num_of_hosts', type=int, help='Number of hosts')
parser.add_argument('-t', '--target', type=str, help='Target URL')
parser.add_argument('-m', '--method', type=str, help='HTTP Method GET or POST')
parser.add_argument('-hd', '--headers', type=str, help='Headers', nargs='*')
parser.add_argument('-p', '--payload', type=str, help='Payload')
args = parser.parse_args()


# Главная функция (получает задание от пользователя и выполняет)
def main():
    if args.task == 'scan':
        for host_num in range(args.num_of_hosts):
            do_ping_sweep(args.ip, host_num)
    elif args.task == 'sendhttp':
        if not (validators.url(args.target) or validators.ipv4(args.target)):
            print(f"[#] Target host '{args.target}' is not valid, enter valid host and try again. Bye")
        else:
            sent_http_request(args.target, args.method, args.headers, args.payload)


# Проверка на доступ в интернет
reachability = Reachability(host='8.8.8.8', port=53, timeout=1, status_check_interval=2)
if reachability.isonline():
    main()
else:
    print(f"[#] Default server is unreachable, so you might not be connected to the internet. Continue? [yes/no] ")
    answer = ''
    while answer != ('yes' or 'no'):
        answer = input()
        if answer == 'yes':
            main()
        elif answer == 'no':
            print(f"[#] Please, try again later. Bye ")
            break
